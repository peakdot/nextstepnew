<?php
$servername = "localhost";
$username = "root";
$pw = "admin";
$dbname = "nextstep_v2";
?>